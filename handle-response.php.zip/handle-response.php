<?php

	//Needed for CORS implementation on PHP
	header("Access-Control-Allow-Origin: http://apps.smsgh.com");
	header("Access-Control-Allow-Methods: OPTIONS, GET, POST");
	header('Content-type: application/json; charset=utf-8');

	header('Content-type: application/json; charset=utf-8'); 

	$ussdRequest = json_decode(@file_get_contents('php://input')); 

	// Check if no errors occured. 
	if ($ussdRequest != NULL) { 

		// Create a response object. 

		$ussdResponse = new stdClass; 

		// Set the message to display. 
		$ussdResponse->Message = "Voting for product of the year opens on the 1st March, 2019. Thank you"; 

		// Set the type of this response. 
		$ussdResponse->Type = "Release"; 

		// Encode the response object as JSON and send. 
		echo json_encode($ussdResponse); 

		// E.g. $ussdRequest->Message, 
		//$ussdRequest->SessionId, etc. 
	}
?>